Morgan Noonan (men83) 4553170

Everything is running fine

#s0: guess count
#s1: wrong word flag
#s2:stores a0
#s3: stores a1
#s4:word length increment for check_letters

#a0: words_matrix address
#a1: myGuess address
#a2: column count
#a3:matches letter/any part of the word
